<?php
    $portfolios = App\Models\portfolios::latest()->get();
?>
<section class="portfolio" id="portfolio">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-6 col-lg-8">
                <div class="section__title text-center">
                    <span class="sub-title">04 - Portfolio</span>
                    <h2 class="title">All creative work</h2>
                </div>
            </div>
        </div>
    </div>
    <div class="tab-content" id="portfolioTabContent">
        <div class="tab-pane show active" id="all" role="tabpanel" aria-labelledby="all-tab">
            <div class="container">
                <div class="row gx-0 justify-content-center">
                    <div class="col">
                        <div class="portfolio__active">
                            <?php $__empty_1 = true; $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="portfolio__item">
                                    <div class="portfolio__thumb">
                                        <img src="<?php echo e(!empty($portfolio->portfolio_image) ? url('upload/portfolio/' . $portfolio->portfolio_image) : url('upload/portfolio.png')); ?>"
                                            alt="<?php echo e($portfolio->portfolio_title); ?>">
                                    </div>
                                    <div class="portfolio__overlay__content">
                                        <span><?php echo e($portfolio->portfolio_name); ?></span>
                                        <h4 class="title"><a
                                                href="<?php echo e(route('portfolio.details', $portfolio->id)); ?>"><?php echo e($portfolio->portfolio_title); ?></a>
                                        </h4>
                                        <a href="<?php echo e(route('portfolio.details', $portfolio->id)); ?>" class="link">Case
                                            Study</a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <img src="<?php echo e(asset('no_data.jpg')); ?>">
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH G:\laravel_nine_project\resources\views/frontend/home_all/portfolio.blade.php ENDPATH**/ ?>