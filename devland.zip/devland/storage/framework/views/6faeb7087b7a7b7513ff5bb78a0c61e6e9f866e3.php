<aside class="blog__sidebar">
    <div class="widget">
        <form action="#" class="search-form">
            <input type="text" placeholder="Search">
            <button type="submit"><i class="fal fa-search"></i></button>
        </form>
    </div>
    <div class="widget">
        <h4 class="widget-title">Recent Blog</h4>
        <ul class="rc__post">
            <?php $__currentLoopData = $allBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="rc__post__item">
                    <div class="rc__post__thumb">
                        <a href="<?php echo e(route('blog.details', $data->id)); ?>"><img
                                src="<?php echo e(!empty($data->blog_image) ? url('upload/blog/' . $data->blog_image) : url('upload/service.png')); ?>"
                                alt="<?php echo e($data->blog_title); ?>"></a>

                    </div>
                    <div class="rc__post__content">
                        <h5 class="title"><a href="<?php echo e(route('blog.details', $data->id)); ?>"><?php echo e($data->blog_title); ?></a>
                        </h5>
                        <span class="post-date"><i class="fal fa-calendar-alt"></i>
                            <?php echo e(Carbon\Carbon::parse($data->created_at)->diffForHumans()); ?></span>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>
    </div>
    <div class="widget">
        <h4 class="widget-title">Categories</h4>
        <ul class="sidebar__cat">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $catWiseBlogsCount = App\Models\Blogs::catWiseBlogsCount($category->id);
                ?>
                <li class="sidebar__cat__item"><a
                        href="<?php echo e(route('category.blogs', $category->id)); ?>"><?php echo e($category->blog_category); ?>

                        <?php if($catWiseBlogsCount != 0): ?>
                            <?php echo e('(' . $catWiseBlogsCount . ')'); ?>

                        <?php endif; ?>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</aside>
<?php /**PATH G:\laravel_nine_project\resources\views/frontend/components/blog_right_sidebar.blade.php ENDPATH**/ ?>