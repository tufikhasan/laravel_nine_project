
<?php $__env->startSection('site_title'); ?>
    Blogs - Personal Portfolio
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <!-- breadcrumb-area -->
    <section class="breadcrumb__wrap">
        <div class="container custom-container">
            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-8 col-md-10">
                    <div class="breadcrumb__wrap__content">
                        <h2 class="title">Recent Article</h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">BLOG</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="breadcrumb__wrap__icon">
            <ul>
                <?php $__currentLoopData = $multi_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><img src="<?php echo e(url('upload/multi/' . $image->image)); ?>" alt=""></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </section>
    <!-- breadcrumb-area-end -->


    <!-- blog-area -->

    <!-- blog-area-end -->

    <!-- blog-area -->
    <section class="standard__blog">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <?php $__empty_1 = true; $__currentLoopData = $allBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="standard__blog__post">
                            <div class="standard__blog__thumb">
                                <a href="<?php echo e(route('blog.details', $data->id)); ?>"><img
                                        src="<?php echo e(!empty($data->blog_image) ? url('upload/blog/' . $data->blog_image) : url('upload/service.png')); ?>"
                                        alt="<?php echo e($data->blog_title); ?>"></a>
                                <a href="<?php echo e(route('blog.details', $data->id)); ?>" class="blog__link"><i
                                        class="far fa-long-arrow-right"></i></a>
                            </div>
                            <div class="standard__blog__content">
                                <h2 class="title"><a
                                        href="<?php echo e(route('blog.details', $data->id)); ?>"><?php echo e($data->blog_title); ?></a></h2>
                                <div>
                                    <?php echo Str::limit($data->blog_description, 60); ?>

                                </div>
                                <ul class="blog__post__meta">
                                    <li><i class="fal fa-calendar-alt"></i>
                                        <?php echo e(Carbon\Carbon::parse($data->created_at)->diffForHumans()); ?></li>
                                </ul>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <img src="<?php echo e(asset('no_data.jpg')); ?>">
                    <?php endif; ?>

                    <div class="pagination-wrap">
                        <?php echo e($allBlogs->links('vendor.pagination.custom_pagination')); ?>

                    </div>
                </div>
                <div class="col-lg-4">
                    <?php echo $__env->make('frontend.components.blog_right_sidebar', [
                        'allBlogs' => $allBlogs,
                        'categories' => $categories,
                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </section>
    <!-- blog-area-end -->

    <!-- Say-Hello -->
    <?php echo $__env->make('frontend.components.say_hello', [
        'sayHelloSectionCss' => 'homeContact homeContact__style__two',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Say-Hello -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel_nine_project\resources\views/frontend/blogs/blog_page.blade.php ENDPATH**/ ?>