<?php
    $blogs = App\Models\Blogs::latest()
        ->limit(3)
        ->get();
?>
<section class="blog">
    <div class="container">
        <div class="row gx-0 justify-content-center">
            <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-lg-4 col-md-6 col-sm-9">
                    <div class="blog__post__item">
                        <div class="blog__post__thumb">
                            <a href="<?php echo e(route('blog.details', $blog->id)); ?>">
                                <img src="<?php echo e(!empty($blog->blog_image) ? url('upload/blog/' . $blog->blog_image) : url('upload/service.png')); ?>"
                                    alt="<?php echo e($blog->blog_title); ?>">
                            </a>
                            <div class="blog__post__tags">
                                <a
                                    href="<?php echo e(route('blog.details', $blog->id)); ?>"><?php echo e($blog['categoryFun']['blog_category']); ?></a>
                            </div>
                        </div>
                        <div class="blog__post__content">
                            <span class="date"> <?php echo e(Carbon\Carbon::parse($blog->created_at)->diffForHumans()); ?></span>
                            <h3 class="title"><a
                                    href="<?php echo e(route('blog.details', $blog->id)); ?>"><?php echo e($blog->blog_title); ?></a></h3>
                            <a href="<?php echo e(route('blog.details', $blog->id)); ?>" class="read__more">Read mORe</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <img src="<?php echo e(asset('no_data.jpg')); ?>">
            <?php endif; ?>

        </div>
    </div>
</section>
<?php /**PATH G:\laravel_nine_project\resources\views/frontend/home_all/blog.blade.php ENDPATH**/ ?>