@include('admin.body.header')
@include('admin.body.sidebar')

<div class="main-content">
    @yield('admin')
    <!-- End Page-content -->
    @include('admin.body.footer')
