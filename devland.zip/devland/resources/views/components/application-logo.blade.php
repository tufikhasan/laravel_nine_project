<img src="{{ asset('logo_black.svg') }}" alt="Logo" width="150" />
