## Run multiple seeders in one command

```
php artisan db:seed

```

## Run Specific seeder

```
php artisan db:seed --class=HomeSeeder
php artisan db:seed --class=AboutSeeder
php artisan db:seed --class=PartnerSeeder
php artisan db:seed --class=FooterSeeder

```
